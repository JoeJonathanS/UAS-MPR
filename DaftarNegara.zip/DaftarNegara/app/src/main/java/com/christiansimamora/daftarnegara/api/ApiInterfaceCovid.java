package com.christiansimamora.daftarnegara.api;

import com.christiansimamora.daftarnegara.model.AllCountryResponseModel;
import com.christiansimamora.daftarnegara.model.CountryResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface ApiInterfaceCovid {

    @GET("countries/?sort=country")
    Call<List<CountryResponse>> getCountries();


    @GET("countries/{country}")
    Call<CountryResponse> getCountryInfo(@Path("country") String country);

    @GET("all")
    Call<AllCountryResponseModel> getAllCountries();

}
