package com.christiansimamora.daftarnegara.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.christiansimamora.daftarnegara.R;
import com.squareup.picasso.Picasso;

public class DetailActivity extends AppCompatActivity {

    ImageView imgNegara;
    TextView txtNamaNegara;
    TextView txtKasusHariIni;
    TextView txtMati;
    TextView txtTotalTest;
    TextView txtTotalKasus;
    TextView txtTotalKematian;
    TextView txtTotalSembuh;
    TextView txtIbuKota;
    TextView txtKodeNegara;
    TextView txtTitleIbuKota;
    TextView txtTItleKodeNegara;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        imgNegara = findViewById(R.id.imgNegara);
        txtNamaNegara = findViewById(R.id.txtNamaNegara);
        txtKasusHariIni = findViewById(R.id.txtKasusHariIni);
        txtMati = findViewById(R.id.txtMati);
        txtTotalTest = findViewById(R.id.txtTotalTest);
        txtTotalKasus = findViewById(R.id.txtTotalKasus);
        txtTotalKematian = findViewById(R.id.txtTotalKematian);
        txtTotalSembuh = findViewById(R.id.txtTotalSembuh);
        txtIbuKota = findViewById(R.id.txtIbuKota);
        txtKodeNegara = findViewById(R.id.txtKodeNegara);
        txtTitleIbuKota = findViewById(R.id.txtTitleIbuKota);
        txtTItleKodeNegara = findViewById(R.id.txtTItleKodeNegara);

        String countryName = getIntent().getStringExtra("country");
        String todayCase = getIntent().getStringExtra("todayCase");
        String todayDeath = getIntent().getStringExtra("todayDeath");
        String totalCases = getIntent().getStringExtra("cases");
        String totalDeaths = getIntent().getStringExtra("deaths");
        String totalTests = getIntent().getStringExtra("tests");
        String totalRecovered = getIntent().getStringExtra("recovered");

        txtNamaNegara.setText(countryName);
        txtKasusHariIni.setText(todayCase);
        txtMati.setText(todayDeath);
        txtTotalTest.setText(totalTests);
        txtTotalKasus.setText(totalCases);
        txtTotalKematian.setText(totalDeaths);
        txtTotalSembuh.setText(totalRecovered);

        Picasso.with(getApplicationContext()).
                load(getIntent().getStringExtra("flag"))
                .into(imgNegara);

        setupDetail();
    }

    private void setupDetail() {
        final String namaNegara = txtNamaNegara.getText().toString();
        if (namaNegara.equals("Brazil")) {
            txtIbuKota.setText("Brasilia");
            txtKodeNegara.setText("+55");
        } else if(namaNegara.equals("Zimbabwe")) {
            txtIbuKota.setText("Harace");
            txtKodeNegara.setText("+263");
        } else if(namaNegara.equals("Vietnam")) {
            txtIbuKota.setText("Hanoi");
            txtKodeNegara.setText("+84");
        } else if(namaNegara.equals("Venezuela")) {
            txtIbuKota.setText("Caracas");
            txtKodeNegara.setText("+58");
        } else if(namaNegara.equals("Zambia")) {
            txtIbuKota.setText("Lusaka");
            txtKodeNegara.setText("+260");
        } else {
            txtTitleIbuKota.setVisibility(View.GONE);
            txtTItleKodeNegara.setVisibility(View.GONE);
            txtIbuKota.setVisibility(View.GONE);
            txtKodeNegara.setVisibility(View.GONE);
        }
    }
}